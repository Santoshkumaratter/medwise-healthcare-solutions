<?php
return [
  'GMAIL_USER' => 'tejaswiulhalkar1996@gmail.com',
  'FORM_TO_EMAIL' => 'tejaswiulhalkar1996@gmail.com',
  'GMAIL_APP_PASSWORD' => 'iodv abhs tgjw zzwb',
];